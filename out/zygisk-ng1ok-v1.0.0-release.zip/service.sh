MODDIR=${0%/*}

echo "2: $(date)\n" >> $MODDIR\log.txt