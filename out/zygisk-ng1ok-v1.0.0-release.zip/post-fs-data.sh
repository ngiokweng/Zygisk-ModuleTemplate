MODDIR=${0%/*}

echo "1: $(date)\n" >> $MODDIR\log.txt