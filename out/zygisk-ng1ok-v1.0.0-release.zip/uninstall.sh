#!/sbin/sh
# MODDIR=${0%/*}
rm -rf /data/adb/modules/zygisk_ng1ok
